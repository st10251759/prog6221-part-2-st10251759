using ST10251759_PROG6221_POE_Part_2;

namespace RecipeTest
{
    [TestClass]
    public class CalorieTest
    {
        [TestMethod]
        public void TestCalorieCalculation()
        {
            // Arrange: Set-up the objects, Inputs, expected outcome
            Ingredient ingredient1 = new Ingredient("Mango", 1, UnitOfMeasurement.MEDIUM, FoodGroup.FRUIT, 140);
            Ingredient ingredient2 = new Ingredient("Orange", 2, UnitOfMeasurement.SMALL, FoodGroup.FRUIT, 59);
            Ingredient ingredient3 = new Ingredient("Rolls", 3, UnitOfMeasurement.LARGE, FoodGroup.CARBOHYDRATE, 84);

            List<Ingredient> ingredients = new List<Ingredient>();
            ingredients.Add(ingredient1);
            ingredients.Add(ingredient2);
            ingredients.Add(ingredient3);

            Recipe recipe = new Recipe("Fruit Salad", 3, 2);

            // Act: invoker the method that is actually being tested
            recipe.setIngredients(ingredients);
            double totalCalories = recipe.calculateTotalCalories();

            // Assert: Check that the method behaved as expected
            Assert.AreEqual(283, totalCalories);
        }

        [TestMethod]
        public void TestCalorieAlert()
        {
            // Arrange
            Ingredient ingredient1 = new Ingredient("Mango", 1, UnitOfMeasurement.MEDIUM, FoodGroup.FRUIT, 110);
            Ingredient ingredient2 = new Ingredient("Orange", 2, UnitOfMeasurement.SMALL, FoodGroup.FRUIT, 110);
            Ingredient ingredient3 = new Ingredient("Rolls", 3, UnitOfMeasurement.LARGE, FoodGroup.CARBOHYDRATE, 110);

            List<Ingredient> ingredients = new List<Ingredient>();
            ingredients.Add(ingredient1);
            ingredients.Add(ingredient2);
            ingredients.Add(ingredient3);

            Recipe recipe = new Recipe("Fruit Salad", 3, 2);

            // Act
            recipe.setIngredients(ingredients);
            double totalCalories = recipe.calculateTotalCalories();

            // Assert
            Assert.AreEqual(330, totalCalories);
            recipe.displayCalories();
            // will display calories over 300 warning
        }

        [TestMethod]
        public void TestLowCalorieMeal()
        {
            Recipe recipe = new Recipe("Recipe", 1, 1);
            recipe.setTotalCalories(350);
            recipe.displayCalories();
            string result = recipe.Message();

            Assert.AreEqual("Low Calorie Meal", result);

            // will display calories over 300 warning
            // will display that calory amount is a snack

        }// end test

        [TestMethod]
        public void TestAverageCalorieMeal()
        {
            Recipe recipe = new Recipe("Recipe", 1, 1);
            recipe.setTotalCalories(550);
            recipe.displayCalories();
            string result = recipe.Message();

            Assert.AreEqual("Average Calorie Meal", result);
            // will display calories over 300 warning
            // will display that calory amount is an average calorie meal

        }// end test

        [TestMethod]
        public void TestHighCalorieMeal()
        {
            Recipe recipe = new Recipe("Recipe", 1, 1);
            recipe.setTotalCalories(1000);
            recipe.displayCalories();
            string result = recipe.Message();

            Assert.AreEqual("High Calorie Meal", result);
            // will display calories over 300 warning
            // will display that calory amount is a high calorie meal
        }// end test

        [TestMethod]
        public void TestSnackCalorie()
        {
            Recipe recipe = new Recipe("Recipe", 1, 1);
            recipe.setTotalCalories(150);
            recipe.displayCalories();
            string result = recipe.Message();

            Assert.AreEqual("Snack", result);

            // will display that calorie amount is a snack

        }// end test
    }
}
